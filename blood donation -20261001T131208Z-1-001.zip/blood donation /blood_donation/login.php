<?php
include 'db_connect.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $result = mysqli_query($conn, "SELECT * FROM donors WHERE name='$phone'");
    $user = mysqli_fetch_assoc($result);
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['donor_id'] = $user['donor_id'];
        header("Location: dashboard.php");
    } else {
        echo "Invalid name or Number.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login - Blood Donation System</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .login-container {
            max-width: 400px;
            margin: 80px auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 4px 10px rgba(0,0,0,0.2);
        }
        .login-container h3 {
            color: #dc3545;
            text-align: center;
            margin-bottom: 20px;
        }
        .btn-login {
            width: 100%;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h3>Login</h3>
        <form method="POST" action="login.php">
            <div class="mb-3">
                <input type="name" name="name" class="form-control" placeholder="Name" required>
            </div>
            <div class="mb-3">
                <input type="phone" name="phone" class="form-control" placeholder="Number" required>
            </div>
            <button type="submit" class="btn btn-danger btn-login">Login</button>
        </form>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
