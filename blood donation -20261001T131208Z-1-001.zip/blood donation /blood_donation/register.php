<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name       = $_POST['name'];
    $address      = $_POST['address'];
    $location   = $_POST['location'];
    $phone      = $_POST['phone'];
    $blood_type = $_POST['blood_type'];

    // Check if email already exists
    $check = mysqli_query($conn, "SELECT * FROM donors WHERE phone='$phone'");
    if (mysqli_num_rows($check) > 0) {
        echo "<div style='color:red; text-align:center; margin-top:10px;'>
                This Phone Number is already registered. Try logging in instead.
              </div>";
    } else {
        $sql = "INSERT INTO donors (name, address ,location , phone, blood_type ) 
                VALUES ('$name', '$address', '$location','$phone', '$blood_type')";
        if (mysqli_query($conn, $sql)) {
            echo "<div style='color:green; text-align:center; margin-top:10px;'>
                    Registration successful.
                  </div>";
            // Show the two buttons after success
            echo "
            <div style='text-align:center; margin-top:15px;'>
                <button onclick=\"window.location.href='index.php'\" class='btn btn-primary m-2'>Go to Home Page</button>
                <button onclick=\"window.location.href='login.php'\" class='btn btn-success m-2'>Go to Login Page</button>
            </div>
            ";
        } else {
            echo "<div style='color:red; text-align:center; margin-top:10px;'>
                    Error: " . mysqli_error($conn) . "
                  </div>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Donor Registration</title>
    <!-- Bootstrap CSS CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .form-container {
            max-width: 500px;
            margin: 50px auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0,0,0,0.1);
        }
        button {
            width: 100%;
        }
    </style>
</head>
<body>

<div class="form-container">
    <h3 class="text-center mb-4">Donor Registration</h3>
    <form method="POST" action="register.php">
        <div class="mb-3">
            <input type="text" name="name" class="form-control" placeholder="Full Name" required>
        </div>
        <div class="mb-3">
            <input type="address" name="address" class="form-control" placeholder="Address" required>
        </div>
        <div class="mb-3">
            <input type="text" name="location" class="form-control" placeholder="Area" required>
        </div>
        <div class="mb-3">
            <input type="text" name="phone" class="form-control" placeholder="Phone" required>
        </div>
        <div class="mb-3">
            <select name="blood_type" class="form-select" required>
                <option value="">Select Blood Type</option>
                <option value="A+">A+</option>
                <option value="A-">A-</option>
                <option value="B+">B+</option>
                <option value="B-">B-</option>
                <option value="O+">O+</option>
                <option value="O-">O-</option>
                <option value="AB+">AB+</option>
                <option value="AB-">AB-</option>
            </select>
        </div>

        <button type="submit" class="btn btn-danger">Register</button>
    </form>
</div>

<!-- Bootstrap JS CDN -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
